@echo off
echo ============================================
echo   SkillBridge - Skill Gap Analyser
echo   Building and Starting Server...
echo ============================================
echo.

:: Navigate to project root
cd /d "%~dp0"

:: Create output directory
if not exist "build" mkdir build

:: Compile Java files
echo [1/2] Compiling Java source files...
javac -d build backend\src\main\java\com\skillgap\SkillGapServer.java backend\src\main\java\com\skillgap\SkillGapAnalyzer.java

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Compilation failed! Make sure JDK is installed and in your PATH.
    echo   Download JDK from: https://adoptium.net/
    pause
    exit /b 1
)

echo [2/2] Starting server...
echo.

:: Run the server
java -cp build com.skillgap.SkillGapServer

pause
