package com.skillgap;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Core analysis engine for the Skill Gap Analyser.
 * Contains job role definitions, skill mappings, and analysis logic.
 */
public class SkillGapAnalyzer {

    // ─── Job Role Data Store ──────────────────────────────────────────────
    private static final Map<String, JobRole> JOB_ROLES = new LinkedHashMap<>();

    static {
        // ── Software Development ──
        JOB_ROLES.put("Frontend Developer", new JobRole(
            "Frontend Developer",
            "Software Development",
            Arrays.asList("HTML5", "CSS3", "JavaScript", "React.js", "Vue.js or Angular", "TypeScript", "Responsive Design", "Git", "REST APIs", "Webpack/Vite", "UI/UX Principles", "Testing (Jest/Cypress)"),
            Arrays.asList(
                new LearningResource("HTML & CSS Mastery", "https://developer.mozilla.org/en-US/docs/Learn", "Free", "Beginner"),
                new LearningResource("JavaScript - The Complete Guide", "https://javascript.info", "Free", "Beginner"),
                new LearningResource("React Official Tutorial", "https://react.dev/learn", "Free", "Intermediate"),
                new LearningResource("TypeScript Handbook", "https://www.typescriptlang.org/docs/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$60,000 - $120,000"
        ));

        JOB_ROLES.put("Backend Developer", new JobRole(
            "Backend Developer",
            "Software Development",
            Arrays.asList("Java", "Python or Node.js", "SQL Databases", "NoSQL Databases", "REST API Design", "Microservices", "Docker", "Git", "Linux/Unix", "Security Best Practices", "Cloud Services (AWS/GCP/Azure)", "Message Queues"),
            Arrays.asList(
                new LearningResource("Java Programming Masterclass", "https://dev.java/learn/", "Free", "Beginner"),
                new LearningResource("Database Design & SQL", "https://www.w3schools.com/sql/", "Free", "Beginner"),
                new LearningResource("Docker Getting Started", "https://docs.docker.com/get-started/", "Free", "Intermediate"),
                new LearningResource("AWS Cloud Practitioner", "https://aws.amazon.com/training/", "Paid", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$70,000 - $140,000"
        ));

        JOB_ROLES.put("Full Stack Developer", new JobRole(
            "Full Stack Developer",
            "Software Development",
            Arrays.asList("HTML5", "CSS3", "JavaScript", "React.js or Angular", "Node.js or Java", "SQL & NoSQL Databases", "REST APIs", "Git", "Docker", "Cloud Services", "CI/CD Pipelines", "TypeScript", "Testing Frameworks"),
            Arrays.asList(
                new LearningResource("The Odin Project", "https://www.theodinproject.com/", "Free", "Beginner"),
                new LearningResource("Full Stack Open", "https://fullstackopen.com/en/", "Free", "Intermediate"),
                new LearningResource("Docker & Kubernetes", "https://docs.docker.com/", "Free", "Advanced"),
                new LearningResource("System Design Primer", "https://github.com/donnemartin/system-design-primer", "Free", "Advanced")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$80,000 - $150,000"
        ));

        JOB_ROLES.put("Mobile App Developer", new JobRole(
            "Mobile App Developer",
            "Software Development",
            Arrays.asList("Kotlin/Swift", "React Native or Flutter", "Mobile UI Design", "REST APIs", "SQLite/Realm", "Push Notifications", "App Store Deployment", "Git", "Firebase", "Performance Optimization", "Offline Storage", "Testing"),
            Arrays.asList(
                new LearningResource("Android Development with Kotlin", "https://developer.android.com/courses", "Free", "Beginner"),
                new LearningResource("Flutter Complete Guide", "https://flutter.dev/docs", "Free", "Beginner"),
                new LearningResource("iOS Development with Swift", "https://developer.apple.com/tutorials/", "Free", "Intermediate"),
                new LearningResource("Firebase Documentation", "https://firebase.google.com/docs", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$65,000 - $130,000"
        ));

        JOB_ROLES.put("DevOps Engineer", new JobRole(
            "DevOps Engineer",
            "Software Development",
            Arrays.asList("Linux Administration", "Docker", "Kubernetes", "CI/CD (Jenkins/GitHub Actions)", "AWS/GCP/Azure", "Terraform/Ansible", "Monitoring (Prometheus/Grafana)", "Scripting (Bash/Python)", "Networking", "Security", "Git", "Infrastructure as Code"),
            Arrays.asList(
                new LearningResource("Linux Administration", "https://linuxjourney.com/", "Free", "Beginner"),
                new LearningResource("Docker Deep Dive", "https://docs.docker.com/", "Free", "Intermediate"),
                new LearningResource("Kubernetes Documentation", "https://kubernetes.io/docs/", "Free", "Intermediate"),
                new LearningResource("AWS Solutions Architect", "https://aws.amazon.com/certification/", "Paid", "Advanced")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$90,000 - $160,000"
        ));

        // ── Data & AI ──
        JOB_ROLES.put("Data Scientist", new JobRole(
            "Data Scientist",
            "Data & AI",
            Arrays.asList("Python", "R Programming", "Statistics & Probability", "Machine Learning", "Deep Learning", "SQL", "Data Visualization (Matplotlib/Tableau)", "Pandas/NumPy", "TensorFlow/PyTorch", "Feature Engineering", "A/B Testing", "Big Data (Spark)"),
            Arrays.asList(
                new LearningResource("Python for Data Science", "https://www.kaggle.com/learn", "Free", "Beginner"),
                new LearningResource("Statistics & Probability", "https://www.khanacademy.org/math/statistics-probability", "Free", "Beginner"),
                new LearningResource("Machine Learning by Andrew Ng", "https://www.coursera.org/learn/machine-learning", "Free", "Intermediate"),
                new LearningResource("Deep Learning Specialization", "https://www.deeplearning.ai/", "Paid", "Advanced")
            ),
            "Master's/PhD in CS, Statistics, Mathematics or related",
            "$95,000 - $170,000"
        ));

        JOB_ROLES.put("Data Analyst", new JobRole(
            "Data Analyst",
            "Data & AI",
            Arrays.asList("SQL", "Excel Advanced", "Python or R", "Data Visualization (Tableau/Power BI)", "Statistics", "Data Cleaning", "Business Intelligence", "ETL Processes", "Critical Thinking", "Communication Skills", "Dashboard Design"),
            Arrays.asList(
                new LearningResource("SQL for Data Analysis", "https://mode.com/sql-tutorial/", "Free", "Beginner"),
                new LearningResource("Excel Skills for Business", "https://www.coursera.org/specializations/excel", "Free", "Beginner"),
                new LearningResource("Tableau Training", "https://www.tableau.com/learn/training", "Free", "Intermediate"),
                new LearningResource("Google Data Analytics Certificate", "https://www.coursera.org/professional-certificates/google-data-analytics", "Paid", "Beginner")
            ),
            "Bachelor's in any analytical field",
            "$50,000 - $90,000"
        ));

        JOB_ROLES.put("ML Engineer", new JobRole(
            "ML Engineer",
            "Data & AI",
            Arrays.asList("Python", "Machine Learning Algorithms", "Deep Learning (TensorFlow/PyTorch)", "MLOps", "Docker", "Cloud ML Services", "Data Pipelines", "Model Deployment", "SQL", "Git", "Linux", "Mathematics (Linear Algebra, Calculus)"),
            Arrays.asList(
                new LearningResource("Fast.ai Practical Deep Learning", "https://course.fast.ai/", "Free", "Intermediate"),
                new LearningResource("MLOps Specialization", "https://www.deeplearning.ai/courses/machine-learning-engineering-for-production-mlops/", "Paid", "Advanced"),
                new LearningResource("Mathematics for ML", "https://mml-book.github.io/", "Free", "Intermediate"),
                new LearningResource("Kaggle Competitions", "https://www.kaggle.com/competitions", "Free", "Intermediate")
            ),
            "Master's in CS/ML or equivalent experience",
            "$100,000 - $180,000"
        ));

        JOB_ROLES.put("AI Engineer", new JobRole(
            "AI Engineer",
            "Data & AI",
            Arrays.asList("Python", "Deep Learning", "Natural Language Processing", "Computer Vision", "LLMs & Prompt Engineering", "TensorFlow/PyTorch", "Cloud AI Services", "MLOps", "Docker", "API Development", "Mathematics", "Research Paper Reading"),
            Arrays.asList(
                new LearningResource("Deep Learning Specialization", "https://www.deeplearning.ai/", "Paid", "Intermediate"),
                new LearningResource("Hugging Face NLP Course", "https://huggingface.co/learn/nlp-course", "Free", "Intermediate"),
                new LearningResource("Stanford CS231n (Computer Vision)", "http://cs231n.stanford.edu/", "Free", "Advanced"),
                new LearningResource("LangChain Documentation", "https://docs.langchain.com/", "Free", "Intermediate")
            ),
            "Master's/PhD in CS, AI or related field",
            "$110,000 - $200,000"
        ));

        // ── Cybersecurity ──
        JOB_ROLES.put("Cybersecurity Analyst", new JobRole(
            "Cybersecurity Analyst",
            "Cybersecurity",
            Arrays.asList("Network Security", "SIEM Tools", "Vulnerability Assessment", "Incident Response", "Firewalls & IDS/IPS", "Linux/Windows Administration", "Python Scripting", "Risk Assessment", "Compliance (GDPR/HIPAA)", "Encryption", "Threat Intelligence", "Security Frameworks (NIST)"),
            Arrays.asList(
                new LearningResource("CompTIA Security+", "https://www.comptia.org/certifications/security", "Paid", "Beginner"),
                new LearningResource("TryHackMe Learning Paths", "https://tryhackme.com/", "Free/Paid", "Beginner"),
                new LearningResource("Cybersecurity Fundamentals", "https://www.sans.org/cyber-security-courses/", "Paid", "Intermediate"),
                new LearningResource("CEH Certification", "https://www.eccouncil.org/programs/certified-ethical-hacker-ceh/", "Paid", "Intermediate")
            ),
            "Bachelor's in CS/IT/Cybersecurity",
            "$65,000 - $120,000"
        ));

        JOB_ROLES.put("Ethical Hacker", new JobRole(
            "Ethical Hacker",
            "Cybersecurity",
            Arrays.asList("Penetration Testing", "Web Application Security", "Network Security", "Kali Linux", "Metasploit", "Burp Suite", "Python/Bash Scripting", "OWASP Top 10", "Social Engineering", "Wireless Security", "Reverse Engineering", "Report Writing"),
            Arrays.asList(
                new LearningResource("Hack The Box Academy", "https://academy.hackthebox.com/", "Free/Paid", "Beginner"),
                new LearningResource("OSCP Certification", "https://www.offsec.com/courses/pen-200/", "Paid", "Advanced"),
                new LearningResource("PortSwigger Web Security Academy", "https://portswigger.net/web-security", "Free", "Intermediate"),
                new LearningResource("PentesterLab", "https://pentesterlab.com/", "Paid", "Intermediate")
            ),
            "Bachelor's in CS/IT/Cybersecurity",
            "$70,000 - $140,000"
        ));

        // ── Design ──
        JOB_ROLES.put("UI/UX Designer", new JobRole(
            "UI/UX Designer",
            "Design",
            Arrays.asList("Figma", "Adobe XD", "User Research", "Wireframing", "Prototyping", "Design Systems", "Typography", "Color Theory", "Usability Testing", "Responsive Design", "Accessibility (WCAG)", "Interaction Design"),
            Arrays.asList(
                new LearningResource("Google UX Design Certificate", "https://www.coursera.org/professional-certificates/google-ux-design", "Paid", "Beginner"),
                new LearningResource("Figma Official Tutorials", "https://www.figma.com/resources/learn-design/", "Free", "Beginner"),
                new LearningResource("Laws of UX", "https://lawsofux.com/", "Free", "Intermediate"),
                new LearningResource("Nielsen Norman Group Articles", "https://www.nngroup.com/articles/", "Free", "Intermediate")
            ),
            "Bachelor's in Design, HCI, or related field",
            "$55,000 - $110,000"
        ));

        JOB_ROLES.put("Graphic Designer", new JobRole(
            "Graphic Designer",
            "Design",
            Arrays.asList("Adobe Photoshop", "Adobe Illustrator", "Typography", "Color Theory", "Layout Design", "Brand Identity", "Print Design", "Digital Design", "Motion Graphics (After Effects)", "Adobe InDesign", "Creative Thinking", "Communication Skills"),
            Arrays.asList(
                new LearningResource("Adobe Creative Cloud Tutorials", "https://helpx.adobe.com/creative-cloud/tutorials-explore.html", "Free", "Beginner"),
                new LearningResource("Canva Design School", "https://www.canva.com/designschool/", "Free", "Beginner"),
                new LearningResource("Typography Fundamentals", "https://practicaltypography.com/", "Free", "Beginner"),
                new LearningResource("Skillshare Design Classes", "https://www.skillshare.com/", "Paid", "Intermediate")
            ),
            "Bachelor's in Graphic Design or related field",
            "$40,000 - $80,000"
        ));

        // ── Cloud & Infrastructure ──
        JOB_ROLES.put("Cloud Architect", new JobRole(
            "Cloud Architect",
            "Cloud & Infrastructure",
            Arrays.asList("AWS/Azure/GCP", "Infrastructure as Code (Terraform)", "Networking (VPC, DNS, Load Balancers)", "Security & IAM", "Containerization (Docker/Kubernetes)", "Serverless Architecture", "Cost Optimization", "High Availability Design", "Monitoring & Logging", "Database Services", "CI/CD Pipelines", "Disaster Recovery"),
            Arrays.asList(
                new LearningResource("AWS Solutions Architect Associate", "https://aws.amazon.com/certification/certified-solutions-architect-associate/", "Paid", "Intermediate"),
                new LearningResource("Google Cloud Architect", "https://cloud.google.com/certification/cloud-architect", "Paid", "Advanced"),
                new LearningResource("Terraform Documentation", "https://developer.hashicorp.com/terraform/docs", "Free", "Intermediate"),
                new LearningResource("Cloud Design Patterns", "https://docs.microsoft.com/en-us/azure/architecture/patterns/", "Free", "Advanced")
            ),
            "Bachelor's in CS/IT with cloud certifications",
            "$120,000 - $200,000"
        ));

        // ── Product & Management ──
        JOB_ROLES.put("Product Manager", new JobRole(
            "Product Manager",
            "Product & Management",
            Arrays.asList("Product Strategy", "User Research", "Data Analysis", "Agile/Scrum", "Roadmap Planning", "Stakeholder Management", "A/B Testing", "Market Analysis", "SQL Basics", "Wireframing", "Communication Skills", "Leadership"),
            Arrays.asList(
                new LearningResource("Product Management Course", "https://www.productschool.com/", "Paid", "Beginner"),
                new LearningResource("Inspired by Marty Cagan", "https://www.svpg.com/inspired-how-to-create-products-customers-love/", "Paid", "Intermediate"),
                new LearningResource("Agile & Scrum Fundamentals", "https://www.scrum.org/resources", "Free", "Beginner"),
                new LearningResource("Google Analytics Academy", "https://analytics.google.com/analytics/academy/", "Free", "Beginner")
            ),
            "Bachelor's in Business, CS, or related field + experience",
            "$90,000 - $160,000"
        ));

        JOB_ROLES.put("Project Manager", new JobRole(
            "Project Manager",
            "Product & Management",
            Arrays.asList("Project Planning", "Agile/Scrum/Kanban", "Risk Management", "Budgeting", "Stakeholder Communication", "JIRA/Trello", "MS Project", "Team Leadership", "Conflict Resolution", "Documentation", "PMP Certification Knowledge", "Time Management"),
            Arrays.asList(
                new LearningResource("PMP Certification Prep", "https://www.pmi.org/certifications/project-management-pmp", "Paid", "Intermediate"),
                new LearningResource("Google Project Management Certificate", "https://www.coursera.org/professional-certificates/google-project-management", "Paid", "Beginner"),
                new LearningResource("Scrum Master Certification", "https://www.scrum.org/assessments/professional-scrum-master-i-certification", "Paid", "Intermediate"),
                new LearningResource("Atlassian Agile Coach", "https://www.atlassian.com/agile", "Free", "Beginner")
            ),
            "Bachelor's in any field + PMP preferred",
            "$70,000 - $130,000"
        ));

        // ── Digital Marketing ──
        JOB_ROLES.put("Digital Marketing Specialist", new JobRole(
            "Digital Marketing Specialist",
            "Digital Marketing",
            Arrays.asList("SEO/SEM", "Google Analytics", "Social Media Marketing", "Content Marketing", "Email Marketing", "PPC Advertising", "Google Ads", "Facebook/Meta Ads", "Copywriting", "Marketing Automation", "CRM Tools", "Data Analysis"),
            Arrays.asList(
                new LearningResource("Google Digital Marketing Certificate", "https://skillshop.withgoogle.com/", "Free", "Beginner"),
                new LearningResource("HubSpot Academy", "https://academy.hubspot.com/", "Free", "Beginner"),
                new LearningResource("SEO Learning Center (Moz)", "https://moz.com/learn/seo", "Free", "Intermediate"),
                new LearningResource("Facebook Blueprint", "https://www.facebook.com/business/learn", "Free", "Intermediate")
            ),
            "Bachelor's in Marketing, Business, or related field",
            "$45,000 - $85,000"
        ));

        // ── Database ──
        JOB_ROLES.put("Database Administrator", new JobRole(
            "Database Administrator",
            "Cloud & Infrastructure",
            Arrays.asList("SQL (MySQL/PostgreSQL/Oracle)", "Database Design & Normalization", "Performance Tuning", "Backup & Recovery", "Replication & Clustering", "NoSQL (MongoDB/Redis)", "Security & Access Control", "Cloud Database Services", "ETL Processes", "Scripting (Bash/Python)", "Monitoring Tools", "High Availability"),
            Arrays.asList(
                new LearningResource("SQL & Database Fundamentals", "https://www.w3schools.com/sql/", "Free", "Beginner"),
                new LearningResource("PostgreSQL Documentation", "https://www.postgresql.org/docs/", "Free", "Intermediate"),
                new LearningResource("Oracle DBA Certification", "https://education.oracle.com/", "Paid", "Advanced"),
                new LearningResource("MongoDB University", "https://university.mongodb.com/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$65,000 - $120,000"
        ));

        // ── QA / Testing ──
        JOB_ROLES.put("QA Engineer", new JobRole(
            "QA Engineer",
            "Software Development",
            Arrays.asList("Manual Testing", "Test Automation (Selenium/Cypress)", "API Testing (Postman/RestAssured)", "Performance Testing (JMeter)", "Test Planning & Strategy", "Bug Tracking (JIRA)", "SQL Basics", "Git", "CI/CD Understanding", "Agile/Scrum", "Python/Java Basics", "Security Testing Basics"),
            Arrays.asList(
                new LearningResource("ISTQB Foundation Level", "https://www.istqb.org/", "Paid", "Beginner"),
                new LearningResource("Selenium WebDriver Tutorial", "https://www.selenium.dev/documentation/", "Free", "Intermediate"),
                new LearningResource("Postman Learning Center", "https://learning.postman.com/", "Free", "Beginner"),
                new LearningResource("Test Automation University", "https://testautomationu.applitools.com/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$55,000 - $100,000"
        ));

        // ── Blockchain ──
        JOB_ROLES.put("Blockchain Developer", new JobRole(
            "Blockchain Developer",
            "Emerging Technologies",
            Arrays.asList("Solidity", "Ethereum & Smart Contracts", "Web3.js/Ethers.js", "Cryptography Fundamentals", "Consensus Mechanisms", "DeFi Protocols", "Hardhat/Truffle", "IPFS", "Token Standards (ERC-20/721)", "Security Auditing", "JavaScript/TypeScript", "Rust (for Solana)"),
            Arrays.asList(
                new LearningResource("CryptoZombies", "https://cryptozombies.io/", "Free", "Beginner"),
                new LearningResource("Ethereum Developer Documentation", "https://ethereum.org/en/developers/", "Free", "Intermediate"),
                new LearningResource("Alchemy University", "https://university.alchemy.com/", "Free", "Intermediate"),
                new LearningResource("Solidity by Example", "https://solidity-by-example.org/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "$80,000 - $180,000"
        ));
    }

    /**
     * Performs the skill gap analysis and returns a JSON response.
     */
    public static String analyze(String name, String age, String education, String desiredJob, String currentSkillsStr) {
        JobRole role = JOB_ROLES.get(desiredJob);
        if (role == null) {
            return "{\"error\": \"Job role not found: " + escapeJson(desiredJob) + "\"}";
        }

        // Parse current skills
        Set<String> currentSkills = new HashSet<>();
        if (currentSkillsStr != null && !currentSkillsStr.trim().isEmpty()) {
            for (String skill : currentSkillsStr.split(",")) {
                currentSkills.add(skill.trim().toLowerCase());
            }
        }

        // Determine which required skills the user already has and which they need
        List<String> matchedSkills = new ArrayList<>();
        List<String> missingSkills = new ArrayList<>();

        for (String requiredSkill : role.requiredSkills) {
            boolean hasSkill = false;
            for (String userSkill : currentSkills) {
                if (requiredSkill.toLowerCase().contains(userSkill) || userSkill.contains(requiredSkill.toLowerCase())) {
                    hasSkill = true;
                    break;
                }
            }
            if (hasSkill) {
                matchedSkills.add(requiredSkill);
            } else {
                missingSkills.add(requiredSkill);
            }
        }

        // Calculate readiness percentage
        int totalSkills = role.requiredSkills.size();
        int matchedCount = matchedSkills.size();
        int readinessPercent = totalSkills > 0 ? (matchedCount * 100) / totalSkills : 0;

        // Determine readiness level
        String readinessLevel;
        String readinessMessage;
        if (readinessPercent >= 80) {
            readinessLevel = "Advanced";
            readinessMessage = "Excellent! You're almost job-ready. Focus on the few remaining skills to become a strong candidate.";
        } else if (readinessPercent >= 50) {
            readinessLevel = "Intermediate";
            readinessMessage = "Good progress! You have a solid foundation. Dedicate time to learning the missing skills to stand out.";
        } else if (readinessPercent >= 25) {
            readinessLevel = "Beginner";
            readinessMessage = "You've made a start! There are several key skills to develop. Follow a structured learning path to build your expertise.";
        } else {
            readinessLevel = "Getting Started";
            readinessMessage = "This is a new field for you, but that's okay! Everyone starts somewhere. Follow the recommended resources to begin your journey.";
        }

        // Estimate learning time (rough: 2-4 weeks per skill)
        int estimatedWeeks = missingSkills.size() * 3;
        String estimatedTime;
        if (estimatedWeeks <= 4) {
            estimatedTime = estimatedWeeks + " weeks";
        } else {
            int months = estimatedWeeks / 4;
            estimatedTime = months + " - " + (months + 2) + " months";
        }

        // Build JSON response
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        json.append("  \"name\": \"").append(escapeJson(name)).append("\",\n");
        json.append("  \"age\": \"").append(escapeJson(age)).append("\",\n");
        json.append("  \"education\": \"").append(escapeJson(education)).append("\",\n");
        json.append("  \"desiredJob\": \"").append(escapeJson(desiredJob)).append("\",\n");
        json.append("  \"category\": \"").append(escapeJson(role.category)).append("\",\n");
        json.append("  \"readinessPercent\": ").append(readinessPercent).append(",\n");
        json.append("  \"readinessLevel\": \"").append(readinessLevel).append("\",\n");
        json.append("  \"readinessMessage\": \"").append(escapeJson(readinessMessage)).append("\",\n");
        json.append("  \"recommendedEducation\": \"").append(escapeJson(role.recommendedEducation)).append("\",\n");
        json.append("  \"salaryRange\": \"").append(escapeJson(role.salaryRange)).append("\",\n");
        json.append("  \"estimatedLearningTime\": \"").append(escapeJson(estimatedTime)).append("\",\n");
        json.append("  \"totalRequiredSkills\": ").append(totalSkills).append(",\n");
        json.append("  \"matchedSkillsCount\": ").append(matchedCount).append(",\n");
        json.append("  \"missingSkillsCount\": ").append(missingSkills.size()).append(",\n");

        // Matched skills array
        json.append("  \"matchedSkills\": [");
        for (int i = 0; i < matchedSkills.size(); i++) {
            json.append("\"").append(escapeJson(matchedSkills.get(i))).append("\"");
            if (i < matchedSkills.size() - 1) json.append(", ");
        }
        json.append("],\n");

        // Missing skills array
        json.append("  \"missingSkills\": [");
        for (int i = 0; i < missingSkills.size(); i++) {
            json.append("\"").append(escapeJson(missingSkills.get(i))).append("\"");
            if (i < missingSkills.size() - 1) json.append(", ");
        }
        json.append("],\n");

        // All required skills
        json.append("  \"allRequiredSkills\": [");
        for (int i = 0; i < role.requiredSkills.size(); i++) {
            json.append("\"").append(escapeJson(role.requiredSkills.get(i))).append("\"");
            if (i < role.requiredSkills.size() - 1) json.append(", ");
        }
        json.append("],\n");

        // Learning resources
        json.append("  \"learningResources\": [\n");
        for (int i = 0; i < role.resources.size(); i++) {
            LearningResource res = role.resources.get(i);
            json.append("    {\"title\": \"").append(escapeJson(res.title))
                .append("\", \"url\": \"").append(escapeJson(res.url))
                .append("\", \"cost\": \"").append(escapeJson(res.cost))
                .append("\", \"level\": \"").append(escapeJson(res.level))
                .append("\"}");
            if (i < role.resources.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("  ]\n");

        json.append("}");

        return json.toString();
    }

    /**
     * Returns a JSON array of all available job roles grouped by category.
     */
    public static String getJobRolesJson() {
        // Group by category
        Map<String, List<String>> grouped = new LinkedHashMap<>();
        for (Map.Entry<String, JobRole> entry : JOB_ROLES.entrySet()) {
            String category = entry.getValue().category;
            grouped.computeIfAbsent(category, k -> new ArrayList<>()).add(entry.getKey());
        }

        StringBuilder json = new StringBuilder();
        json.append("{\n  \"categories\": [\n");

        int catIndex = 0;
        for (Map.Entry<String, List<String>> entry : grouped.entrySet()) {
            json.append("    {\n");
            json.append("      \"name\": \"").append(escapeJson(entry.getKey())).append("\",\n");
            json.append("      \"jobs\": [");
            for (int i = 0; i < entry.getValue().size(); i++) {
                json.append("\"").append(escapeJson(entry.getValue().get(i))).append("\"");
                if (i < entry.getValue().size() - 1) json.append(", ");
            }
            json.append("]\n");
            json.append("    }");
            if (catIndex < grouped.size() - 1) json.append(",");
            json.append("\n");
            catIndex++;
        }

        json.append("  ]\n}");
        return json.toString();
    }

    private static String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }

    // ─── Inner Classes ────────────────────────────────────────────────────

    static class JobRole {
        String title;
        String category;
        List<String> requiredSkills;
        List<LearningResource> resources;
        String recommendedEducation;
        String salaryRange;

        JobRole(String title, String category, List<String> requiredSkills,
                List<LearningResource> resources, String recommendedEducation, String salaryRange) {
            this.title = title;
            this.category = category;
            this.requiredSkills = requiredSkills;
            this.resources = resources;
            this.recommendedEducation = recommendedEducation;
            this.salaryRange = salaryRange;
        }
    }

    static class LearningResource {
        String title;
        String url;
        String cost;
        String level;

        LearningResource(String title, String url, String cost, String level) {
            this.title = title;
            this.url = url;
            this.cost = cost;
            this.level = level;
        }
    }
}
